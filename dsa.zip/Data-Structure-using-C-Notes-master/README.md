# Data-Structure-Using-C-Notes
These are the notes that I made from the course MASTERING DATA STRUCTURES AND ALGORITHMS USING C AND C++ BY ABDUL BARI

<img width="630" alt="Screenshot 2022-06-10 at 3 07 43 PM" src="https://user-images.githubusercontent.com/59398211/173043539-72c6af41-753e-4dee-9860-5384113f4df9.png">
